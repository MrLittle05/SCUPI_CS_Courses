Connect Four Game - README
(a) Dame Chen (b) 2023141520228 (c) All work has been done!

(d)
Welcome to Connect Four!
What is Connect Four?
Connect Four is a two-player game where players take turns dropping discs into a 7x6 grid. The goal is to be the first to align four of your discs in a row—horizontally, vertically, or diagonally.

Player 1: Uses *
Player 2: Uses +
How to Play
Start:
Load connect.asm in a MIPS simulator (like MARS).
Click "Run".
Play:
Enter a column number (0-6) to drop your disc.
Players alternate turns.
Win:
First to connect four discs wins.
Choose to play again or exit after a win.
Requirements
A MIPS assembler and simulator (e.g., MARS).
Enjoy the game!