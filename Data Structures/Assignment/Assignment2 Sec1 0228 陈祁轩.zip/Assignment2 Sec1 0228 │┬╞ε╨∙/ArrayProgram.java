/**
 * An array of Strings program
 */
public class ArrayProgram {

    public static void main(String args[]) {
        String words[] = new String[4];

        words[0] = "I";
        words[1] = "am";
        words[2] = "the";
        words[3] = "eggman";

        for(int i=0;i<=3;i++) {
            System.out.println(words[i]);
        }
    }
}
